<?php

class Withdraw extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('withdraw_model');
        $this->load->model('user_model');
        $this->load->model('withdraw_limit_model');
        
        if ($this->session->userdata('logged_in') != TRUE) {
            redirect('admin');
        }
        
    }

    public function index() {
        $userId = $this->session->userdata('user_id');
        $arrData['withdrawDetails'] = $this->withdraw_model->get_withdraw($userId);
        //echo "<pre>";        print_r($arrData); die;
        $arrData['middle'] = 'admin/withdraw/list';
        $this->load->view('admin/template', $arrData);
    }

    public function delete($IwithdrawId) {
        
    }

    public function userRequest($IwithdrawId) {

        $arrData['withdrawRequest'] = $this->withdraw_model->get_withdraw_request($IwithdrawId);
        //echo "<prE>";        print_r($arrData); die;

        $arrData['middle'] = 'admin/withdraw/edit';
        $this->load->view('admin/template', $arrData);
    }

    public function changeRequest($Request, $requestId) {        
        $userId = $this->session->userdata('user_id');
        $admin_id = $userId;
        $userData = $this->user_model->get_profile($admin_id);      

        $IwithdrawId = $requestId;
        $arrData['withdrawRequest'] = $this->withdraw_model->get_withdraw_request($IwithdrawId);      
        
        $request = $arrData['withdrawRequest']['withdrawl_type'];
        $withLimitData = $this->withdraw_limit_model->getRequestType($request);
        //echo "<prE>";        print_r($withLimitData); die;
        $with_min_limit = $withLimitData['withdraw_limit_min'];
        $with_max_limit = $withLimitData['withdraw_limit_max'];
        $with_fees = $withLimitData['withdraw_limit_fees'];

        $withAmount = $arrData['withdrawRequest']['withdraw_btc_amount'];       
        if ($Request == 'accept') {
            $updateWithdrawal['withdraw_status'] = 1;
        } else if ($Request == 'reject') {

            $updateWithdrawal['withdraw_btc_amount'] = 0;
            
            $updateData['user_attack_player_satoshi'] = $userData['user_attack_player_satoshi'] + $withAmount + $with_fees;
            $updateUserProfile = $this->user_model->update_Profile($admin_id, $updateData);
            $updateWithdrawal['withdraw_status'] = 2;
        }

        $update = $this->withdraw_model->updateWithdrawRequest($requestId, $updateWithdrawal);
        if ($update) {
            $this->session->set_flashdata('success', 'Request Update Success !');
            redirect('admin/withdraw');
        }
    }

}
?>

