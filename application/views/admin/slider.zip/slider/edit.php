<script>
    $(document).ready(function ()
    {
        $('#editSlider').validate(
                {
                    rules:
                            {
                                imgUplod:
                                        {
                                            required: true
                                        }
                            },
                    messages:
                            {
                                imgUplod:
                                        {
                                            required: ''
                                        }
                            }
                });
    });
</script>
<div class="container-fluid">
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class=""  style="float:left">
                    <h4 class="page-title">Edit Slider</h4>                    
                </div>                
                <div class=""  style="float:right">
                    <h4 class="page-title">
                        <a href="<?php echo base_url('admin/slider'); ?>" class="btn btn-primary">
                            List All
                        </a>
                    </h4>                    
                </div> 
                <div class="clearfix"></div>                
            </div>            
        </div>
    </div> 
    <?php
    $formEdit = array(
        'id' => 'editSlider',
        'name' => 'editSlider'
    );
    echo form_open_multipart('admin/slider/edit/'.$editSlider['0']['slider_id'], $formEdit);
    ?>
    <div class="container-fluid">
        <div class="form-group">
            <div class="row">
                <div class="col-md-1">
                    Image
                </div>                
                <div class="col-md-3">
                    <img src="<?php echo base_url() . '/admin_assets/assets/images/slider/' . $editSlider[0]['slider_image'] ?>" width="100px">
                </div>                
            </div>            
        </div>
        <div class="form-group">
            <div class="row">

                <div class="offset-md-1 col-md-3">
                    <?php
                    $fileData = array(
                        'id' => 'imgUplod',
                        'name' => 'imgUplod'
                    );

                    echo form_upload($fileData);
                    ?>
                </div>                
            </div>            
        </div>
    </div>
    <div class="container">        
        <div class="row">                
            <div class="offset-md-1 col-md-3">
                <?php
                $submit = array(
                    'id' => 'imgUplod',
                    'name' => 'imgUplod'
                );
                echo form_submit('cmdSubmit', 'Submit', $submit);
                ?>
                <input type="hidden" id="imgHiddenId" name="imgHiddenId" value="<?php echo $editSlider[0]['slider_id'] ?>">
            </div>
        </div>
    </div>
    <?php
    echo form_close();
    ?>
</div>