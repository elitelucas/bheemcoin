
<script>

    function change_image()
    {
        var src = $('#myimage').attr('src');
        if (src == 'http://bheemcoin.com/client_assets/assets/login.jpg')
        {
            $("#myimage").attr("src", "http://bheemcoin.com/client_assets/assets/work.png");
            $("#description_run").empty();
            $("#description_run").append("We are working, 1 satoshi/min for 20min is collected by dholu");
        } else if (src == "http://bheemcoin.com/client_assets/assets/work.png")
        {
            $("#myimage").attr("src", "http://bheemcoin.com/client_assets/assets/login.jpg");
            $("#description_run").empty();
            $("#description_run").append("We are working, 1 satoshi/min for 20min is collected by dholu");
        }
    }
</script>

<section id="main-content">
    <div class="row">
        <div class="small-16 large-16 columns">
            <h3 style="text-align:center;"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;Edit ACCOUNT </h3>
            <h3 style="text-align:center;">YOUR WALLET : <span style="font-family:cursive;font-size:20px;"><?php echo $user[0]['bitcoin_address']; ?></span></h3>

            <center>
                <div class="button-group" style="padding-bottom:3%;">
                    <a href="<?php echo site_url('welcome/edit_profile/' . $user[0]['username']); ?>" class="button" style="font-size:20px;color: #20160c;
                       font-weight: 800;    padding: 0.7em 3em;">Edit Profile</a>
                    <a href="<?php echo site_url('welcome/change_wallet/' . $user[0]['username']); ?>" class="button" style="font-size:20px; color: #20160c;
                       font-weight: 800;   padding: 0.7em 3em;">Change Wallet</a>
                    <a href="<?php echo site_url('welcome/change_password/' . $user[0]['username']); ?>" class="button" style="font-size:20px; color: #20160c;
                       font-weight: 800;   padding: 0.7em 3em;">Change Password</a>
                </div>
            </center>

            <div class="small-16 large-5 columns">

                <img src="<?php echo base_url(); ?>client_assets/assets/gifts.png" alt="" class="thumbnail" style="">

            </div>
            <div class="small-16 large-5 columns">

                <img src="<?php echo base_url(); ?>client_assets/assets/explore.png" alt="" class="thumbnail">

            </div>
            <div class="small-16 large-5 columns" style="float:left;">

                <img src="<?php echo base_url(); ?>client_assets/assets/foodstore.png" alt="" class="thumbnail">

            </div>
        </div>
        <div class="row ">

            <div class="small-16 large-16 columns">

                <div class="article-content small-16 large-16 columns" style="margin-top: 4%;">
                    <div class="small-16 large-8 columns">

                    </div>
                    <div class="small-16 large-8 columns">

                        <img id="myimage" src="<?php echo base_url(); ?>client_assets/assets/login.jpg" alt="" class="thumbnail">
                        <center>
                            <h3 style="color: yellow;text-decoration: underline;">We're free</h3></center>
                        <center style="    font-size: 19px;"><a href="#." id="clickMe" onclick="change_image();" style="color: yellow;text-decoration: underline;">Click here</a> <span id="description_run">if you want dholu bholu to run </span></center>
                    </div>

                </div>

            </div>

        </div>
        <div class="row ">

            <div class="small-16 large-16 columns">

                <div class="article-content small-16 large-16 columns" style="margin-top: 4%;">
                    <div class="small-16 large-8 columns">

                        <img src="<?php echo base_url(); ?>client_assets/assets/collect.png" alt="" class="thumbnail">
                        <center> <a class="expanded lime-button" href="#" style="margin-top:2%;">Withdraw</a></center>

                    </div>
                    <div class="small-16 large-8 columns">

                        <img src="<?php echo base_url(); ?>client_assets/assets/collect2.png" alt="" class="thumbnail">
                        <center><a class="expanded lime-button" href="#" style="margin-top:2%;">Collect</a> </center>

                    </div>

                </div>

            </div>

            <!--//main-->

            <!--sidebar-->

            <!--//sidebar-->
        </div>

        <div class="row" style="padding-top:8%;">
            <div class="small-16 large-16 columns">
                <h3 style="text-align:center;">Scores</h3>
                <div class="clearfix small-up-1 medium-up-2 large-up-3" data-equalizer data-equalize-on="medium">
                    <div class="column">
                        <div class="callout" data-equalizer-watch>
                            <ul style="font-size:18px;line-height:2.2;">
                                <li>My Satoshi Balance: 299</li>
                                <li>Satoshi Last Deposit: 0.0500 BTC</li>
                                <li>Pending BTC: 0 Satoshi </li>
                                <li>Paid BTC: 26,459,740 </li>

                            </ul>
                        </div>
                    </div>
                    <div class="column">
                        <div class="callout" data-equalizer-watch>
                            <ul style="font-size:18px;line-height:2.2;">
                                <li>Generated: 37 Satoshi</li>
                                <li>My Speed: 60 Satoshi/ Hour </li>
                                <li>My Capacity: 36 Satoshi </li>

                            </ul>
                        </div>
                    </div>
                    <div class="column">
                        <div class="callout" data-equalizer-watch>
                            <h3 style="text-align:center;">Satoshi Won </h3>
                            <h3 style="text-align:center;"> 37/37</h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>  
</section>




