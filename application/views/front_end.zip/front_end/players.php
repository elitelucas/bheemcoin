<section id="main-content">
    <div class="row">
        <h3 style="text-align:center;padding-bottom:3%;">Change Players </h3>
        <p style="    text-align: center;
           font-size: 19px;
           line-height: 2;
           color: #c5db3b;
           font-weight: bold;
           padding-bottom: 5%;">Play more and do collects to find new STARS!</br>You can find up to 3 stars every day!</br>STARS can be used to rent new players</p>

        <div class="small-16 large-16 columns" style="padding-bottom:5%;">
            <div class="small-8 large-8 columns">

                <center>
                    <h4 style="padding-bottom:2%;">Yours Stars</h4></center>
                <center> <img src="<?php echo base_url(); ?>client_assets/assets/star.png" class="" alt=""></center>

            </div>
            <div class="small-8 large-8 columns">

                <center>
                    <h4 style="padding-bottom:2%;">Yours Score</h4></center>
                <center> <img src="<?php echo base_url(); ?>client_assets/assets/money.png" class="" alt=""></center>
            </div>
        </div>

        <div class="small-16 large-16 columns" style="  background: url(<?php echo base_url(); ?>client_assets/assets/players.jpg) no-repeat;
             background-repeat: no-repeat;
             -webkit-background-size: cover;
             -moz-background-size: cover;
             -o-background-size: cover;padding:100px 0;
             background-size: cover;
             background-position: center;">
            <table>

                <tbody>

                    <tr>
                        <th><img src="<?php echo base_url(); ?>client_assets/assets/players/bar1.png" class="opacity_img"></br>
                            </br><span style="    font-family: cursive;
                                       font-size: 18px;
                                       color: yellow;">100 Satoshi</span></br><a href="#"><img src="<?php echo base_url(); ?>client_assets/assets/players/player1.png" class="opacity_img"></a></th>
                        <th><img src="<?php echo base_url(); ?>client_assets/assets/players/bar2.png" class="opacity_img"></br>
                            </br><span style="    font-family: cursive;
                                       font-size: 18px;
                                       color: yellow;">100 Satoshi</span></br><a href="#"><img src="<?php echo base_url(); ?>client_assets/assets/players/player2.png" class="opacity_img"></a></th>
                        <th><img src="<?php echo base_url(); ?>client_assets/assets/players/bar3.png" class="opacity_img"></br>
                            </br><span style="    font-family: cursive;
                                       font-size: 18px;
                                       color: yellow;">10 Stars</span></br><a href="#"><img src="<?php echo base_url(); ?>client_assets/assets/players/player3.png" class="opacity_img"></a></th>
                        <th><img src="<?php echo base_url(); ?>client_assets/assets/players/bar4.png" class="opacity_img"></br>
                            </br><span style="    font-family: cursive;font-size: 18px;color: yellow;">20 Stars</span></br><a href="#"><img src="<?php echo base_url(); ?>client_assets/assets/players/player4.png" class="opacity_img"></a></th>
                        <th><img src="<?php echo base_url(); ?>client_assets/assets/players/bar5.png" class="opacity_img"></br>
                            </br><span style="    font-family: cursive;
                                       font-size: 18px;
                                       color: yellow;">0.005 BTC</span></br><a href="#"><img src="<?php echo base_url(); ?>client_assets/assets/players/player5.png" class="opacity_img"></a></th>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="small-16 large-16 columns" style=" margin-bottom:4%;   background-color: rgba(175, 139, 18, 0.53);margin-top: -7%;padding-bottom:3%;">
            <h3 style="text-align:center;padding-top:2%;">Player Change </h3>
            <p style="text-align:center;line-height:2;font-size:20px;">Make sure you have enough starts to change your player. </br>
                Players for stars will remain 2 days only, then will swich back to Jerry player as default. </br>
                Tom and Jerry players will remain for lifetime.</p>
            <center><a class="expanded lime-button" href="<?php echo site_url('welcome/index'); ?>">Back</a></center>
        </div>
    </div>
</section>