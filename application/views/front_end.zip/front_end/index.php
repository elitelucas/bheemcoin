
<section id="main-content">
    <div class="row">
        <div id="featured-games" class="small-16 large-16 columns">
            <h2 class="title" style="padding-bottom:2%;text-align:center;">Welcome to BheemCoin.com !</h2>
            <p style="text-align:center;padding-bottom:2%;    color: #c5db3b;
               font-size: 20px;">Bheemcoin is Bitcoin Generator Game to get bitcoins every minute. Try it !Refer your friends, enemies and everyone else and receive 20% lifetime commission on all their claims. We have no minimum payout, and always instant !</p>
            <div id="jssor_1" style="    border: 3px solid #c5db3b;position: relative; margin: 0 auto; top: 0px; left: 0px; width: 1920px; height: 650px; overflow: hidden; visibility: hidden;">
                <!-- Loading Screen -->
                <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
                    <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
                    <div style="position:absolute;display:block;background:url('<?php echo base_url(); ?>client_assets/img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
                </div>
                <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 1920px; height: 650px;  overflow: hidden;">

                    <div data-p="225.00" style="display: none;">
                        <img data-u="image" src="<?php echo base_url(); ?>client_assets/assets/banners/b1.png" />

                        <div style="position: absolute;
                             top: 313px;
                             left: 37px;
                             padding: 3%;
                             width: 639px;
                             text-shadow: 2px 1px 4px #171716;
                             height: 286px;
                             font-weight: bold;
                             background-color: rgba(197, 219, 59, 0.61);
                             text-transform: uppercase;
                             font-size: 50px;
                             color: #241707;
                             line-height: 71px;">Instantly Free </br><span style=" color: #d21510;text-shadow: 3px 4px 2px #000;">Bitcoin Generator</span></br><span style=" color: #fff;text-shadow: 3px 4px 2px #000;">Game For all !</span></div>
                    </div>
                    <div data-p="225.00" style="display: none;">
                        <img data-u="image" src="<?php echo base_url(); ?>client_assets/assets/banners/b2.png" />
                        <div style="position: absolute;
                             top: 64px;
                             left: 1218px;
                             padding: 3%;
                             width: 639px;
                             text-shadow: 2px 1px 4px #171716;
                             height: 531px;
                             font-weight: bold;
                             background-color: rgba(197, 219, 59, 0.61);
                             text-transform: uppercase;
                             font-size: 50px;
                             color: #241707;
                             line-height: 75px;">Free Members </br><span style=" color: #d21510;text-shadow: 3px 4px 2px #000;">Get 2 or 5 Satoshi's</span></br><span style=" color: #fff;text-shadow: 3px 4px 2px #000;">Every 5 Minutes</span> </br><span>Upgraded</b> Get</span></br><span>Up to <b>10</b> Satoshi's</span></br><span style="color: #fff;">Every 5 Minutes</span></div>

                    </div>
                    <div data-p="225.00" style="display: none;">
                        <img data-u="image" src="<?php echo base_url(); ?>client_assets/assets/banners/b3.png" />
                        <div style="position: absolute;
                             top: 64px;
                             left:50px;
                             padding: 3%;
                             width: 639px;
                             text-shadow: 2px 1px 4px #171716;
                             height: 481px;
                             font-weight: bold;
                             background-color: rgba(197, 219, 59, 0.61);
                             text-transform: uppercase;
                             font-size: 50px;
                             color: #241707;
                             line-height: 75px;">Win Free Daily Gifts</br><span style=" color: #d21510;text-shadow: 3px 4px 2px #000;">upto (~500 Satoshi)</span></br><span style=" text-shadow: 3px 4px 2px #000;">based on</span> </br><span style=" color: #fff;text-shadow: 3px 4px 2px #000;">Bitcoin price</span></div>

                    </div>
                </div>
                <!-- Bullet Navigator -->
                <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
                    <!-- bullet navigator item prototype -->
                    <div data-u="prototype" style="width:16px;height:16px;"></div>
                </div>
                <!-- Arrow Navigator -->
                <span data-u="arrowleft" class="jssora22l" style="top:0px;left:12px;width:40px;height:58px;" data-autocenter="2"></span>
                <span data-u="arrowright" class="jssora22r" style="top:0px;right:12px;width:40px;height:58px;" data-autocenter="2"></span>
                <a href="http://www.jssor.com" style="display:none">Slideshow Maker</a>
            </div>
        </div>

    </div>
    <div class="row game-presentation" style="padding-top:5%;">

        <div class="small-16 large-16 columns">
            <div class="game-description">
                <h2 style="    font-size: 35px;text-align:center;">Join and have fun with games inside!</h2>

                <img src="<?php echo base_url(); ?>client_assets/assets/home.jpg" style="position:relative;left:15px;" />

                <div class="details-link">
                    <center><a href="<?php echo site_url('welcome/register'); ?>" style="color:#261100">Register now</a></center>
                </div>
            </div>

        </div>
    </div>

    <div class="row team">
        <h3 style="text-align:center;padding-bottom:3%;">Read funny chhota bheem comics and magazines, Have fun with other players online</h3>
        <div class="small-16 columns">
            <div class="row small-up-1 medium-up-2 large-up-4">

                <!--team-member-->
                <div class="column team-member">
                    <div class="photo">
                        <img src="<?php echo base_url(); ?>client_assets/assets/book2.png" class="" alt="">
                    </div>

                </div>
                <!--//team-member-->
                <div class="column team-member">
                    <div class="photo">
                        <img src="<?php echo base_url(); ?>client_assets/assets/book1.png" class="" alt="">
                    </div>

                </div>
                <!--team-member-->
                <div class="column team-member">
                    <div class="photo">
                        <img src="<?php echo base_url(); ?>client_assets/assets/book3.png" class="" alt="">
                    </div>

                </div>
                <!--//team-member-->

                <!--team-member-->
                <div class="column team-member">
                    <div class="photo">
                        <img src="<?php echo base_url(); ?>client_assets/assets/book4.png" class="" alt="">
                    </div>

                </div>
                <!--//team-member-->

            </div>
        </div>
    </div>
    <div class="row game-presentation">
        <div class="small-16 large-9 columns">
            <img src="<?php echo base_url(); ?>client_assets/assets/game.png" alt="" class="thumbnail" />

        </div>
        <div class="small-16 large-7 columns">
            <div class="game-description">
                <h2>Play <span style="color:#5254c6;">Bheem</span> <span style="color:#3c9f3e;">Coin</span></h2>
                <h4 style="color:yellow">On your mobile Phone !</h4>
                <p style="text-align:justify;">
                    Chhota Bheem is an Indian animated comedy adventure television series created by Rajiv Chilaka. Premiered in 2008 on Pogo TV, it focuses on adventures of a boy named Bheem and his friends in the fictional kingdom of Dholakpur. In this series, Bheem and his friends are usually involved in protecting Raja Indravarma, the king of Dholakpur and his kingdom from various evil forces. Sometimes they also help other kingdoms. It is one of the most popular animated series for children in India.</p>
                </p>

                <ul style="font-weight:bold;color:yellow;list-style:none;line-height:2;">
                    <li><i class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Mobile Friendly game</li>
                    <li><i class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Play it for free</li>
                    <li><i class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Instant account Creation</li>

                </ul>

            </div>

        </div>
    </div>

</section>

<section style="margin-top:3%; margin-bottom:3%;   background-color:rgba(50, 34, 9, 0.64);
         padding: 5%">
    <h2 style="text-align:center;padding-bottom:2%;">Join and have fun with games inside!</h2>
    <div class="row ">
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation1.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">
            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation2.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation3.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation4.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
    </div>

    <div class="row " style="padding-top:4%;">
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation5.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">
            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation6.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation7.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
        <div class="small-8 large-4 columns">

            <img src="<?php echo base_url(); ?>client_assets/assets/Animation/animation8.gif" alt="" style="border: 1px solid #e8cb38;
                 padding: 5px;" />

        </div>
    </div>
</section>

