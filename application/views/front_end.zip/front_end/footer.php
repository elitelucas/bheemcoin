
<section style="    background: url(<?php echo base_url();?>client_assets/assets/foot.png) no-repeat;
    background-repeat: no-repeat;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;padding-top: 10%;
    background-size: cover;
    background-position: center;">

 <div class="row" >
        <div class="small-8 large-5 columns"  style=" background: url(<?php echo base_url();?>client_assets/assets/footer2.png) no-repeat;">
          
         
        </div>
        <div class="small-8 large-5 columns">
         <img src="<?php echo base_url();?>client_assets/assets/footer2.png" alt="" />

          
        </div>
		<div class="small-8 large-5 columns" style="float:left;">
                 <img src="<?php echo base_url();?>client_assets/assets/footer3.png" alt="" />
 
        </div>
      </div>	  
    </section>


<div>
    <footer>
      <div class="row">
        <!--social-icons-->
        <div class="small-16 medium-6 columns">
         
        </div>
      
      </div>
    </footer>
		<div class="small-16 medium-16 columns" style="padding-top:1%;">
          <p class="copyright" style="text-align:center;color: yellow;">
			Contact Us | Advertise | <a href="<?php echo site_url('welcome/online_players');?>" style="    color: yellow;">Online Players</a> | Privacy Policy | Terms | Latest Payments | About Us
          </p>
		  <p style="text-align:center;"> Copyright © 2017 Bheemcoin.com All Rights Reserved.</p>
        </div>
</div>